package com.sam.flightsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightSearchMilestone2projectApplicationTests {

	@Test
	void contextLoads() {
	}

}
