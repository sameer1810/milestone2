package com.sam.flightsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightSearchMilestone2projectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightSearchMilestone2projectApplication.class, args);
	}

}
